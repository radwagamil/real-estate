<?php require_once '../private/includes/header.php'; ?>


<div class="w3-container w3-padding-64 w3-center" id="team" >
<h2>OUR TEAM</h2>
<p>Meet the team - our office rats:</p>



<div class="w3-row"><br>

<div class="w3-third">
  <img src="img/asmaa.jpg" alt="CEO" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Asmaa Gamal </h3>
  <p>CEO/ CO-Founder</p>
</div>

<div class="w3-third">
  <img src="img/fatma.jpg" alt="Designer" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3> Fatema Deif</h3>
  <p>Web Designer</p>
</div>

<div class="w3-third">
  <img src="img/radwa.jpg" alt="Architect" style="width:45%" class="w3-circle w3-hover-opacity">
  <h3>Radwa Gamil </h3>
  <p>Architect & Assistant </p>
</div>



</div>
</div>
