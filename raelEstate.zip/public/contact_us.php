<?php require_once '../private/includes/header.php'; ?>


<div class="w3-container w3-padding-64 w3-theme-l5" id="contact">
  <div class="w3-row">
    <div class="w3-col m5">
    <div class="w3-padding-16"><span class="w3-xlarge w3-border-teal w3-bottombar">Contact Us</span></div>
      <h3>Turkey - Istanbul - Esenyurt - RAF</h3>
      <p>Stop & Get Some Coffe Buddy </p>
      <p><i class="fa fa-map-marker w3-text-teal w3-xlarge"></i>Istanbul, Turkey</p>
      <p><i class="fa fa-phone w3-text-teal w3-xlarge"></i> XXXXX </p>
      <p><i class="fa fa-envelope-o w3-text-teal w3-xlarge"></i>RAF@realestate.com</p>
    </div>


    <div class="w3-col m7">
      <form class="w3-container w3-card-4 w3-padding-16 w3-white" target="_blank">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3010.644207015793!2d28.686386315145853!3d41.01116002719675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14caa4f90f7f379b%3A0x59ef6d92f8ccaa5!2z2KfZhNis2KfZhdi52Kkg2KfZhNi52KfZhNmF2YrYqSDZhNmE2KrYrNiv2YrYryAtaXVy!5e0!3m2!1sen!2str!4v1545353695869" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
      </form>
    </div>
  </div>
</div>
