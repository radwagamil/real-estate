<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <title>Istanbul Real State</title>
  </head>
  <body>
    <div class="w3-top">
  <div class="w3-bar w3-white w3-wide w3-padding w3-card">
    <a href="index.php" class="w3-bar-item w3-button"><b>RAF</b> RealEstate</a>
    <div class="w3-right w3-hide-small">
      <a href="about_us.php" class="w3-bar-item w3-button">About</a>
      <a href="contact_us.php" class="w3-bar-item w3-button">Contact</a>
    </div>
  </div>
</div>
